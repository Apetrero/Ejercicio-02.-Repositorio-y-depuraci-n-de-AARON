package pruebas;

public class HolaMundo {

	public static void main(String[] args) {
		// Muestra un texto que dice Hola GIT
		System.out.println("Hola GiT!!");
	}

}
