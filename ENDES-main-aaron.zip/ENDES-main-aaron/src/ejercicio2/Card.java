package ejercicio2;

public class Card {
    // Palo de la carta (como "Spades", "Diamonds", etc...)
    public String suit;
    
    // Valor de la carta (como "Ace", "2", "King", etc...)
    public String value;
    
    // Recibe el palo y valor de la carta
    public Card(String suit, String value) {
        this.suit = suit;   // Asigna el palo
        this.value = value; // Asigna el valor
    }
    
    // Representa la carta en texto
    public String toString() {
        return (this.suit + "-" + this.value); // Devuelve el palo y valor juntos
    }
}

