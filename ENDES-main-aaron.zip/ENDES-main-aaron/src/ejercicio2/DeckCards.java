package ejercicio2;

import java.util.ArrayList;

public class DeckCards {
    public static void main(String[] args) {
        
        // Palos de las cartas
        String[] suits = { "Spades", "Diamonds", "Club", "Heart" };
        
        // Valores de las cartas
        String[] values = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };

        // Lista para almacenar el mazo
        ArrayList<Card> deck = new ArrayList<Card>();

        // Crea el mazo completo
        for (int i = 0; i < suits.length; i++) {
            for (int j = 0; j < values.length; j++) {
                Card card = new Card(suits[i], values[j]); // Crea una carta
                deck.add(card);                            // Añade la carta al mazo
            }
        }

        // Baraja el mazo
        for (int i = 0; i < deck.size(); i++) {
            int j = (int) Math.floor(Math.random() * i); // Factor aleatorio
            Card tmp = deck.get(i);                       // Guarda la carta actual
            deck.set(i, deck.get(j));                     // Intercambia cartas
            deck.set(j, tmp);                             // Completa el intercambio
        }

        // Muestra las primeras cinco cartas del mazo
        for (int i = 0; i < 5; i++) {
            System.out.println(deck.get(i)); // Imprime la carta
        }
    }
}

